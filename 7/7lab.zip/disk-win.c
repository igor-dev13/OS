#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <tchar.h>
#include <string.h>

TCHAR szName[] = TEXT("Global\\MyFileMappingObject");
const minDiskSize = 1;
const maxDiskSize = 100000000;

LPCTSTR diskBuffer;
HANDLE hFile;
HANDLE hMapFile;

FILE *fileptr, *fileptr2;
char *buffer, *buffer2;
size_t filelen;

struct disk
{
	int size;
	int type;
} fileDisk;

struct file
{
	long size;
	long fileSize;
	char name[256];
	int isDeleted;
} fileRecord;

printCommands()
{
	printf("\nUse this commands:\n");
	printf("1. disk.exe format <disk size> <disk name> (min size - 1 and max size - 100000000)\n");
	printf("2. disk.exe dir <disk name>\n");
	printf("3. disk.exe write <disk name> <fileToWriteOnDisk>\n");
	printf("4. disk.exe read <disk name> <fileToReadFromDisk>\n");
	printf("5. disk.exe erease <disk name> <fileToEreaseFromDisk>\n");
	printf("6. disk.exe squeeze <disk name>\n\n");
}

int file_exist(char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

long getFileLength(char *filename)
{
	FILE *exein;
	unsigned long fileLen;
	exein = fopen(filename, "rb");

	if (exein == NULL)
	{
		perror("file open for reading");
		exit(EXIT_FAILURE);
	}

	fseek(exein, 0L, SEEK_END);
	fileLen = ftell(exein);
	fseek(exein, 0L, SEEK_SET);
	fclose(exein);

	return fileLen;
}

int fileMapping(char *fileSize, char *fileName)
{
	long diskSize;

	if (file_exist(fileName))
	{
		diskSize = getFileLength(fileName);
	}
	else
	{
		diskSize = strtol(fileSize, NULL, 10);
	}

	if (diskSize < minDiskSize || diskSize > maxDiskSize)
	{
		printf("Incorrect disk size (min size - 1024000 and max size - 8192000)\n");
		return 1;
	}

	hFile = CreateFileA(fileName, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, NULL, NULL);
	hMapFile = CreateFileMapping(
		hFile,
		NULL,                   // default security
		PAGE_READWRITE,         // read/write access
		0,                      // max. object size
		diskSize,               // buffer size
		szName);                // name of mapping object		

	if (hMapFile == NULL)
	{
		_tprintf(TEXT("Could not create file mapping object (%d).\n"),
			GetLastError());
		return 1;
	}
}

createMapViewOfFile(char *fileName, char *format[])
{
	long diskSize = getFileLength(fileName);

	diskBuffer = (LPTSTR)MapViewOfFile(hMapFile,
		FILE_MAP_ALL_ACCESS,
		0,
		0,
		diskSize);

	if (diskBuffer == NULL)
	{
		printf("Could not map view of file (%d).\n",
			GetLastError());
		return 1;
	}

	if (!strcmp(format, "format"))
	{
		fileDisk.size = diskSize;
		fileDisk.type = 1;

		char diskInfo[sizeof(fileDisk)];
		memcpy(diskInfo, &fileDisk, sizeof(fileDisk));
		memcpy(diskBuffer, &diskInfo, sizeof(fileDisk));
		printf("The disk was successfully created\n");
	}
}

readDiskInfo()
{
	memcpy(&fileDisk, diskBuffer, sizeof(fileDisk));

	printf("\nDISK size - %d\n", fileDisk.size);
	printf("DISK version - %d\n\n", fileDisk.type);
}

int squeezeDisk(char *fileName)
{
	long diskSize = getFileLength(fileName);
	char* newDiskBuffer = (char *)malloc((diskSize + 1) * sizeof(char));

	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		printf("No files found. Nothing to squeeze");
		return 1;
	}
	else
	{
		memcpy(newDiskBuffer, diskBuffer, sizeof(fileDisk));
		long alreadyWrite = sizeof(fileDisk) * 2;
		if (fileRecord.isDeleted == 0)
		{
			memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
			memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
			alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0 && fileRecord.isDeleted == 0)
			{
				memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
				memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
				alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			}
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		memset(diskBuffer, 0, fileDisk.size);
		memcpy(diskBuffer, newDiskBuffer, alreadyWrite);
	}

	printf("squeeze operation made successfuly");
	return 0;
}

int printDiskFiles()
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));
	printf("Stored on the disk:\n\n");

	if (fileRecord.size > 0)
	{
		int fileCount = 1;
		printf("%d. File name - %s\n", fileCount, fileRecord.name);
		printf("File size - %d bytes\n", fileRecord.fileSize);
		printf("Is deleted? - %d\n\n", fileRecord.isDeleted);

		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
				fileCount++;
				printf("%d. File name - %s\n", fileCount, fileRecord.name);
				printf("File size - %d bytes\n", fileRecord.fileSize);
				printf("Is deleted? - %d\n\n", fileRecord.isDeleted);
			}
		}
	}
	else
	{
		printf("No records on Disk\n");
		return 1;
	}
	return 0;
}

int deleteFile(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		printf("NO FILES FOUND");
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			printf("The file was already deleted\n");
			return 1;
		}

		alreadyRead -= (fileRecord.size + fileRecord.fileSize);
		fileRecord.isDeleted = 1;
		char record[sizeof(fileRecord)];
		memcpy(record, &fileRecord, sizeof(fileRecord));
		memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);

		printf("The file was successfuly deleted\n");
		return 0;
	}
	else
	{
		printf("The file not found on DISK\n");
	}
}

readFileFromDisk(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		printf("NO FILES FOUND");
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	alreadyRead -= fileRecord.fileSize;

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			printf("The file was deleted\n");
			return 1;
		}
		printf("file found\n");
		printf("file name - %s\n", fileRecord.name);
		printf("file size - %d\n\n", fileRecord.fileSize);

		buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
		fileptr = fopen(fileName, "wb");
		// fileptr = fopen("2.txt", "wb");
		memcpy(buffer, (diskBuffer + alreadyRead), fileRecord.fileSize);
		fwrite(buffer, fileRecord.fileSize, 1, fileptr);
		fclose(fileptr);
		printf("file restored\n");
	}
}

int writeFileToDisk(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size > 0)
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	fileRecord.size = sizeof(fileRecord);
	fileRecord.fileSize = getFileLength(fileName);
	strcpy(fileRecord.name, fileName);
	fileRecord.isDeleted = 0;

	long checkDiskSpace = fileDisk.size - alreadyRead;
	if (checkDiskSpace < (fileRecord.fileSize + fileRecord.size))
	{
		printf("Not enougth space on disk\n");
		return 1;
	}

	char record[sizeof(fileRecord)];
	memcpy(record, &fileRecord, sizeof(fileRecord));
	memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);
	alreadyRead += fileRecord.size;

	fileptr = fopen(fileName, "rb");
	if (fileptr == NULL)
	{
		printf("Can't open file for reading\n");
		return 1;
	}
	buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
	fread(buffer, fileRecord.fileSize, 1, fileptr);
	memcpy((diskBuffer + alreadyRead), buffer, fileRecord.fileSize);
	fclose(fileptr);
	printf("File successfully recorded\n");
}

diskController(char *argv[])
{
	fileMapping(0, argv[2]);
	createMapViewOfFile(argv[2], "");

	if (!file_exist(argv[2]))
	{
		printf("Disk file to process not found\n");
	}

	if (!strcmp(argv[1], "write"))
	{
		writeFileToDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "read"))
	{
		readFileFromDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "dir"))
	{
		printDiskFiles();
	}
	else if (!strcmp(argv[1], "erease"))
	{
		deleteFile(argv[3]);
	}
	else if (!strcmp(argv[1], "squeeze"))
	{
		squeezeDisk(argv[2]);
	}
	else
	{
		printf("Command do not recognized\n");
	}
}

int main(int argc, char* argv[])
{
	printCommands();

	if (argc < 3)
	{
		return 1;
	}

	if (!strcmp(argv[1], "format"))
	{
		fileMapping(argv[2], argv[3]);
		createMapViewOfFile(argv[3], "format");
	}
	else
	{
		if (!file_exist(argv[2]))
		{
			printf("Disk file not found\n");
			return 1;
		}

		diskController(argv);
	}


	getchar();

	UnmapViewOfFile(diskBuffer);
	CloseHandle(hMapFile);

	return 0;
}