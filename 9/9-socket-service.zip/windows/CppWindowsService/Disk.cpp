
#define _CRT_SECURE_NO_WARNINGS

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
#include <strsafe.h>
#include <string>

char diskDirectory[] = "c:\\Disk\\";
TCHAR createPath[] = L"C:\\Disk";

// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"

#define BUFSIZE 512

WSADATA wsaData;
int iResult;

SOCKET ListenSocket = INVALID_SOCKET;
SOCKET ClientSocket = INVALID_SOCKET;

struct addrinfo *result = NULL;
struct addrinfo hints;

int iSendResult;
char recvbuf[DEFAULT_BUFLEN];
int recvbuflen = DEFAULT_BUFLEN;

DWORD cbBytesRead = 0, cbReplyBytes = 0, cbWritten = 0;
BOOL fSuccess = FALSE;
HANDLE hPipe = NULL;

DWORD WINAPI InstanceThread(LPVOID);
int GetAnswerToRequest(LPTSTR, LPTSTR, LPDWORD, DWORD);

TCHAR szName[] = TEXT("Global\\MyFileMappingObject");
const int minDiskSize = 1;
const int maxDiskSize = 100000000;

LPCTSTR diskBuffer;
HANDLE hFile;
HANDLE hMapFile;

FILE *fileptr, *fileptr2;
char *buffer, *buffer2;
size_t filelen;

struct disk
{
	int size;
	int type;
} fileDisk;

struct file
{
	long size;
	long fileSize;
	char name[256];
	int isDeleted;
} fileRecord;

int writeToSocket(char sockAnswer[], size_t msgSize)
{
	int c = 1, d = 1;
	for (c = 1; c <= 32767; c++)
		for (d = 1; d <= 1024; d++)
		{
		}

	iSendResult = send(ClientSocket, sockAnswer, msgSize, 0);
	if (iSendResult == SOCKET_ERROR) {
		printf("send failed with error: %d\n", WSAGetLastError());
		closesocket(ClientSocket);
		WSACleanup();
		return 1;
	}
	printf("Bytes sent to client: %d\n", iSendResult);

	return 0;
}

int sendExitMessage()
{
	char exitMessage[] = "exit";
	writeToSocket(exitMessage, sizeof(exitMessage));
	return 0;
}

int closeConnection()
{
	sendExitMessage();
	printf("Connection closing...\n");
	UnmapViewOfFile(diskBuffer);
	CloseHandle(hMapFile);
	closesocket(ClientSocket);
	WSACleanup();
	return 1;
}

int file_exist(const char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

long getFileLength(const char *filename)
{
	FILE *exein;
	unsigned long fileLen;
	exein = fopen(filename, "rb");

	if (exein == NULL)
	{
		char sockAnswer[] = "Can't open selected file. Closing connection. Check the file in folder 'c:\\Disk\\' \n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		closeConnection();
		exit(EXIT_FAILURE);
	}

	fseek(exein, 0L, SEEK_END);
	fileLen = ftell(exein);
	fseek(exein, 0L, SEEK_SET);
	fclose(exein);

	return fileLen;
}

int fileMapping(const char *fileSize, const char *fileName)
{
	long diskSize;

	if (file_exist(fileName))
	{
		diskSize = getFileLength(fileName);
	}
	else
	{
		diskSize = strtol(fileSize, NULL, 10);
	}

	if (diskSize < minDiskSize || diskSize > maxDiskSize)
	{
		char sockAnswer[] = "Incorrect disk size (min size - 1024000 and max size - 8192000)\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}

	hFile = CreateFileA(fileName, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, NULL, NULL);
	hMapFile = CreateFileMapping(
		hFile,
		NULL,                   // default security
		PAGE_READWRITE,         // read/write access
		0,                      // max. object size
		diskSize,               // buffer size
		szName);                // name of mapping object		

	if (hMapFile == NULL)
	{
		_tprintf(TEXT("Could not create file mapping object (%d).\n"),
			GetLastError());
		return 1;
	}
	return 0;
}

int createMapViewOfFile(const char *fileName, const char format[])
{
	long diskSize = getFileLength(fileName);

	diskBuffer = (LPTSTR)MapViewOfFile(hMapFile,   // handle to map object
		FILE_MAP_ALL_ACCESS, // read/write permission
		0,
		0,
		diskSize);

	if (diskBuffer == NULL)
	{
		char sockAnswer[] = "Could not map view of file (%d).\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));

		printf("Could not map view of file (%d).\n",
			GetLastError());
		return 1;
	}

	if (!strcmp(format, "format"))
	{
		fileDisk.size = diskSize;
		fileDisk.type = 1;

		char diskInfo[sizeof(fileDisk)];
		memcpy(diskInfo, &fileDisk, sizeof(fileDisk));
		memcpy((void*)diskBuffer, &diskInfo, sizeof(fileDisk));

		char sockAnswer[] = "The disk was successfully created\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
	}

	return 0;
}

int readDiskInfo()
{
	memcpy(&fileDisk, diskBuffer, sizeof(fileDisk));

	char sockAnswer[] = "\nDISK size -                            .\n";
	snprintf(sockAnswer + 14, 16, "%d", fileDisk.size);	
	writeToSocket(sockAnswer, sizeof(sockAnswer));	

	return 0;
}

int squeezeDisk(const char *fileName)
{
	long diskSize = getFileLength(fileName);
	char* newDiskBuffer = (char *)malloc((diskSize + 1) * sizeof(char));

	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char sockAnswer[] = "No files found. Nothing to squeeze\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}
	else
	{
		memcpy(newDiskBuffer, diskBuffer, sizeof(fileDisk));
		long alreadyWrite = sizeof(fileDisk) * 2;
		if (fileRecord.isDeleted == 0)
		{
			memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
			memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
			alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0 && fileRecord.isDeleted == 0)
			{
				memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
				memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
				alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			}
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		memset((void*)diskBuffer, 0, fileDisk.size);
		memcpy((void*)diskBuffer, newDiskBuffer, alreadyWrite);
	}

	char sockAnswer[] = "Squeeze operation made successfuly\n";
	writeToSocket(sockAnswer, sizeof(sockAnswer));
	return 0;
}

int printDiskFiles()
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));
	char sockAnswer[] = "Stored on the disk:\n";
	writeToSocket(sockAnswer, sizeof(sockAnswer));

	if (fileRecord.size > 0)
	{
		int fileCount = 1;

		char msgFIle1[] = "File name -                              \n";
		memcpy(msgFIle1 + 14, &fileRecord.name, 20);
		writeToSocket(msgFIle1, sizeof(msgFIle1));

		char msgFIle2[] = "File size -                                \n";
		snprintf(msgFIle2 + 14, sizeof(long), "%ld", fileRecord.fileSize);
		writeToSocket(msgFIle2, sizeof(msgFIle2));

		char msgFIle3[] = "Is deleted -                               \n";
		snprintf(msgFIle3 + 16, sizeof(int), "%d", fileRecord.isDeleted);
		writeToSocket(msgFIle3, sizeof(msgFIle3));

		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
				fileCount++;

				strcpy(msgFIle1, "\nFile name -                                \n");
				memcpy(msgFIle1 + 16, &fileRecord.name, 20);
				writeToSocket(msgFIle1, sizeof(msgFIle1));

				strcpy(msgFIle2, "File size -                                \n");
				snprintf(msgFIle2 + 13, sizeof(long), "%ld", fileRecord.fileSize);
				writeToSocket(msgFIle2, sizeof(msgFIle2));

				strcpy(msgFIle3, "Is deleted -                                \n");
				snprintf(msgFIle3 + 16, sizeof(int), "%d", fileRecord.isDeleted);
				writeToSocket(msgFIle3, sizeof(msgFIle3));
			}
		}
	}
	else
	{
		char sockAnswer[] = "No records on Disk\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}

	return 0;
}

int deleteFile(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char sockAnswer[] = "No files found\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			char sockAnswer[] = "The file was already deleted\n";
			writeToSocket(sockAnswer, sizeof(sockAnswer));
			return 1;
		}

		alreadyRead -= (fileRecord.size + fileRecord.fileSize);
		fileRecord.isDeleted = 1;
		char record[sizeof(fileRecord)];
		memcpy(record, &fileRecord, sizeof(fileRecord));
		memcpy((void*)(diskBuffer + alreadyRead), &record, fileRecord.size);

		char sockAnswer[] = "The file was successfuly deleted\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 0;
	}
	else
	{
		char sockAnswer[] = "The file not found on DISK\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
	}
	return 0;
}

int readFileFromDisk(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char sockAnswer[] = "No files found\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	alreadyRead -= fileRecord.fileSize;

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			char sockAnswer[] = "The file was deleted\n";
			writeToSocket(sockAnswer, sizeof(sockAnswer));
			return 1;
		}

		buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));

		char fileNameRead[256];
		sprintf(fileNameRead, "%s\\%s", diskDirectory, (char *)fileName);

		fileptr = fopen(fileNameRead, "wb");
		// fileptr = fopen("2.txt", "wb");
		memcpy(buffer, (diskBuffer + alreadyRead), fileRecord.fileSize);
		fwrite(buffer, fileRecord.fileSize, 1, fileptr);
		fclose(fileptr);
		free(buffer);
		char sockAnswer[] = "File restored\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
	}
	else
	{
		char sockAnswer[] = "This file not found\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
	}
	return 0;
}

int writeFileToDisk(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size > 0)
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}


	strcpy(fileRecord.name, fileName);
	char fileNameWrite[256];
	sprintf(fileNameWrite, "%s\\%s", diskDirectory, (char *)fileName);

	fileRecord.size = sizeof(fileRecord);
	fileRecord.fileSize = getFileLength(fileNameWrite);	
	fileRecord.isDeleted = 0;

	long checkDiskSpace = fileDisk.size - alreadyRead;
	if (checkDiskSpace < (fileRecord.fileSize + fileRecord.size))
	{
		char sockAnswer[] = "Not enougth space on disk\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}

	char record[sizeof(fileRecord)];
	memcpy(record, &fileRecord, sizeof(fileRecord));
	memcpy((void*)(diskBuffer + alreadyRead), &record, fileRecord.size);
	alreadyRead += fileRecord.size;

	fileptr = fopen(fileNameWrite, "rb");
	if (fileptr == NULL)
	{
		char sockAnswer[] = "Can't open file for reading\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}
	buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
	fread(buffer, fileRecord.fileSize, 1, fileptr);
	memcpy((void*)(diskBuffer + alreadyRead), buffer, fileRecord.fileSize);
	fclose(fileptr);
	char sockAnswer[] = "File successfully recorded\n";
	writeToSocket(sockAnswer, sizeof(sockAnswer));
	return 0;
}

int diskController(const char *argv[])
{
	char discPath[256];
	sprintf(discPath, "%s\\%s", diskDirectory, (char *)argv[2]);

	fileMapping(0, discPath);
	createMapViewOfFile(discPath, "");	

	if (!file_exist(discPath))
	{
		char sockAnswer[] = "Disk file to process not found\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}		

	if (!strcmp(argv[1], "write"))
	{
		writeFileToDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "read"))
	{
		readFileFromDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "dir"))
	{
		printDiskFiles();
	}
	else if (!strcmp(argv[1], "erease"))
	{
		deleteFile(argv[3]);
	}
	else if (!strcmp(argv[1], "squeeze"))
	{
		squeezeDisk(discPath);
	}
	else
	{
		char sockAnswer[] = "Command do not recognized\n";
		writeToSocket(sockAnswer, sizeof(sockAnswer));
		return 1;
	}

	return 0;
}

int sockInit()
{
	CreateDirectory(createPath, NULL);

	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
	if (iResult != 0) {
		printf("getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();
		return 1;
	}

	// Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		printf("socket failed with error: %ld\n", WSAGetLastError());
		freeaddrinfo(result);
		WSACleanup();
		return 1;
	}

	// Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult == SOCKET_ERROR) {
		printf("bind failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	freeaddrinfo(result);

	iResult = listen(ListenSocket, SOMAXCONN);
	if (iResult == SOCKET_ERROR) {
		printf("listen failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	// Accept a client socket
	ClientSocket = accept(ListenSocket, NULL, NULL);
	if (ClientSocket == INVALID_SOCKET) {
		printf("accept failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	// No longer need server socket
	closesocket(ListenSocket);

	// Receive until the peer shuts down the connection
	do {

		iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
		if (iResult > 0) {
			printf("Bytes received: %d\n", iResult);
			printf("%.*s\n", iResult, recvbuf);

			//
			const char *processCommand[5];
			char * processRequest;
			char tempString[BUFSIZE];
			strncpy(tempString, recvbuf, iResult);
			strncpy(tempString + iResult, " ", 1);

			processRequest = strtok(tempString, " ");

			int i = 0;
			while (processRequest != NULL)
			{
				processCommand[i] = processRequest;
				i++;
				processRequest = strtok(NULL, " ");
				if (i == 4)
					break;
			}

			if ((i >= 2) && (processCommand[0] != NULL && processCommand[1] != NULL && processCommand[2] != NULL))
			{
				char pathDisk[256];				

				if (!strcmp(processCommand[0], "exit"))
				{
					return closeConnection();
				}

				if (!strcmp(processCommand[1], "format"))
				{
					
					sprintf(pathDisk, "%s\\%s", diskDirectory, processCommand[3]);
					fileMapping(processCommand[2], pathDisk);
					createMapViewOfFile(pathDisk, "format");
				}
				else
				{
					sprintf(pathDisk, "%s\\%s", diskDirectory, (char *)processCommand[2]);

					if (!file_exist(pathDisk))
					{
						char sockAnswer[] = "Disk file not found Or unknown Command\n";
						writeToSocket(sockAnswer, sizeof(sockAnswer));
					}
					else
					{						
						diskController(processCommand);
					}
				}
			}

			sendExitMessage();
			printf("exitMsg\n");
			//		

		}
		else if (iResult == 0)
		{
			printf("Connection closing...\n");
			UnmapViewOfFile(diskBuffer);
			CloseHandle(hMapFile);
		}
		else {
			printf("recv failed with error: %d\n", WSAGetLastError());
			closesocket(ClientSocket);
			WSACleanup();
			return 1;
		}

	} while (iResult > 0);

	// shutdown the connection since we're done
	iResult = shutdown(ClientSocket, SD_SEND);
	if (iResult == SOCKET_ERROR) {
		printf("shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(ClientSocket);
		WSACleanup();
		return 1;
	}

	// cleanup
	closesocket(ClientSocket);
	WSACleanup();

	return 0;
}