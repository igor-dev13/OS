int sockInit();
