#define _CRT_SECURE_NO_WARNINGS
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>

char message[1024];
char copyMessage[1024];
char buf[sizeof(message)];

printCommands()
{
	printf("\nUse this commands:\n");
	printf("1. disk.exe format <disk size> <disk name> (min size - 1 and max size - 100000000)\n");
	printf("2. disk.exe dir <disk name>\n");
	printf("3. disk.exe write <disk name> <fileToWriteOnDisk>\n");
	printf("4. disk.exe read <disk name> <fileToReadFromDisk>\n");
	printf("5. disk.exe erease <disk name> <fileToEreaseFromDisk>\n");
	printf("6. disk.exe squeeze <disk name>\n");
	printf("7. exit - to close programm\n");
}

int main()
{
    int sock;
    struct sockaddr_in addr;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0)
    {
        perror("socket");
        exit(1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(3425);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if(connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("connect");
        exit(2);
    }

    printCommands();

    while(1)
    {
        printf("\n%s","> ");
        gets(message);
        char* argv[20];
        char* token;

        strcpy(copyMessage, message);
        token = (char *)strtok(copyMessage, " ");
        int i = 0;
        while( token != NULL )
        {
            argv[i] = token;
            i++;
            token = (char *)strtok(NULL, " ");
        }
        argv[i] = NULL;

        send(sock, message, sizeof(message), 0);

        if (!strcmp(argv[0], "exit"))
        {
            break;
            printf("%s", "Close connection");
        }

        while(1)
        {
            recv(sock, buf, sizeof(message), 0);
            if (!strcmp(buf, "exit"))
                break;

            printf("%s", buf);
        }
    }

    close(sock);

    return EXIT_SUCCESS;
}
