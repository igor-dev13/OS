/*
 Server log file - /var/log/syslog
 Creates temp folder in /tmp/DISK/
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <syslog.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>

char diskDirectory[] = "/tmp/DISK";

static void skeleton_daemon()
{
    pid_t pid;
    pid = fork();

    if (pid < 0)
        exit(EXIT_FAILURE);

    if (pid > 0)
        exit(EXIT_SUCCESS);

    if (setsid() < 0)
        exit(EXIT_FAILURE);

    signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);

    pid = fork();

    if (pid < 0)
        exit(EXIT_FAILURE);

    if (pid > 0)
        exit(EXIT_SUCCESS);

    umask(0);

    chdir("/");

    int x;
    for (x = sysconf(_SC_OPEN_MAX); x>=0; x--)
    {
        close (x);
    }

    openlog ("firstdaemon", LOG_PID, LOG_DAEMON);
}

int sock, listener;
struct sockaddr_in addr;
char buf[1024];
int bytes_read;

const minDiskSize = 1;
const maxDiskSize = 100000000;

void *diskBuffer;
int hMapFile;
int result;

FILE *fileptr, *fileptr2;
char *buffer, *buffer2;
size_t filelen;

struct disk
{
	int size;
	int type;
} fileDisk;

struct file
{
	long size;
	long fileSize;
	char name[256];
	int isDeleted;
} fileRecord;

int file_exist(char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

long getFileLength(char *filename)
{
	FILE *exein;
	unsigned long fileLen;
	exein = fopen(filename, "rb");

	if (exein == NULL)
	{
		perror("file open for reading");
		exit(EXIT_FAILURE);
	}

	fseek(exein, 0L, SEEK_END);
	fileLen = ftell(exein);
	fseek(exein, 0L, SEEK_SET);
	fclose(exein);

	return fileLen;
}

int fileMapping(char *fileSize, char *fileName, char *format[])
{
	long diskSize;

	if (file_exist(fileName))
	{
		diskSize = getFileLength(fileName);
	}
	else
	{
		diskSize = strtol(fileSize, NULL, 10);
	}

	if (diskSize < minDiskSize || diskSize > maxDiskSize)
	{
        char msg[] = "Incorrect disk size (min size - 1 and max size - 8192000)\n";
        send(sock, msg, bytes_read, 0);

		return EXIT_FAILURE;;
	}

    if (!strcmp((char *)format, "format"))
    {
        hMapFile = open(fileName, O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
    }
    else
    {
        hMapFile = open(fileName, O_RDWR);
    }

    if (hMapFile == -1) {
        perror("Error opening file for writing");
        exit(EXIT_FAILURE);
    }

	if (!strcmp((char *)format, "format"))
    {
        result = lseek(hMapFile, diskSize-1, SEEK_SET);
        if (result == -1)
        {
            close(hMapFile);
            perror("Error calling lseek() to 'stretch' the file");
            exit(EXIT_FAILURE);
        }

        result = write(hMapFile, "", 1);
        if (result != 1)
        {
            close(hMapFile);
            perror("Error writing last byte of the file");
            exit(EXIT_FAILURE);
        }
    }
}

createMapViewOfFile(char *fileName, char *format[])
{
	long diskSize = getFileLength(fileName);
    diskBuffer = mmap((caddr_t)0, diskSize, PROT_READ | PROT_WRITE, MAP_SHARED, hMapFile, 0);

    if (diskBuffer == MAP_FAILED)
    {
        close(hMapFile);
        perror("Error mmapping the file");

        char msg[] = "Error mmapping the file\n";
        send(sock, msg, bytes_read, 0);

        exit(EXIT_FAILURE);
    }

	if (!strcmp((char *)format, "format"))
	{
		fileDisk.size = diskSize;
		fileDisk.type = 1;

		char diskInfo[sizeof(fileDisk)];
		memcpy(diskInfo, &fileDisk, sizeof(fileDisk));
		memcpy(diskBuffer, &diskInfo, sizeof(fileDisk));

        char msg[] = "The disk was successfully created\n";
        send(sock, msg, bytes_read, 0);
	}
}

readDiskInfo()
{
	memcpy(&fileDisk, diskBuffer, sizeof(fileDisk));

    char msg[] = "\nDISK size -                            .\n";
    snprintf(msg + 14, 16, "%d", fileDisk.size);
    char msg1[] = "\n";

    send(sock, msg, bytes_read, 0);
    send(sock, msg1, bytes_read, 0);
}

printExitMsg()
{
    char msg[] = "exit";
    send(sock, msg, bytes_read, 0);
}

int squeezeDisk(char *fileName)
{
	long diskSize = getFileLength(fileName);
	char* newDiskBuffer = (char *)malloc((diskSize + 1) * sizeof(char));

	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char msg[] = "No files found. Nothing to squeeze\n";
        send(sock, msg, bytes_read, 0);
		return EXIT_FAILURE;;
	}
	else
	{
		memcpy(newDiskBuffer, diskBuffer, sizeof(fileDisk));
		long alreadyWrite = sizeof(fileDisk);
		if (fileRecord.isDeleted == 0)
		{
			memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
			memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
			alreadyWrite += (fileRecord.size + fileRecord.fileSize);
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0 && fileRecord.isDeleted == 0)
			{
				memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
				memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
				alreadyWrite += (fileRecord.size + fileRecord.fileSize);
			}
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		memset(diskBuffer, 0, fileDisk.size);
		memcpy(diskBuffer, newDiskBuffer, alreadyWrite);
	}

	char msg[] = "Squeeze operation made successfuly\n";
	send(sock, msg, bytes_read, 0);
	return EXIT_SUCCESS;
}

int printDiskFiles()
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

    char msg[] = "\nStored on the disk:\n";
    send(sock, msg, bytes_read, 0);

	if (fileRecord.size > 0)
	{
		int fileCount = 1;

        char msgFIle1[] = "\nFile name -                     \n";
        memcpy(msgFIle1 + 14, &fileRecord.name, 20);
        send(sock, msgFIle1, bytes_read, 0);

        char msgFIle2[] = "\nFile size -         bytes \n";
        snprintf(msgFIle2 + 14, sizeof(long), "%ld", fileRecord.fileSize);
        send(sock, msgFIle2, bytes_read, 0);

        char msgFIle3[] = " bytes\nIs deleted -         \n";
        snprintf(msgFIle3 + 20, sizeof(int), "%d", fileRecord.isDeleted);
        send(sock, msgFIle3, bytes_read, 0);

		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
				fileCount++;

				strcpy (msgFIle1,"\n\nFile name -                     \n");
                memcpy(msgFIle1 + 16, &fileRecord.name, 20);
                send(sock, msgFIle1, bytes_read, 0);

                strcpy (msgFIle2,"\nFile size -         bytes \n");
                snprintf(msgFIle2 + 13, sizeof(long), "%ld", fileRecord.fileSize);
                send(sock, msgFIle2, bytes_read, 0);

                strcpy (msgFIle3," bytes\nIs deleted -         \n");
                snprintf(msgFIle3 + 20, sizeof(int), "%d", fileRecord.isDeleted);
                send(sock, msgFIle3, bytes_read, 0);
			}
		}
	}
	else
	{
		char diskStored[] = "No records on Disk\n";
		send(sock, diskStored, bytes_read, 0);
		return EXIT_FAILURE;;
	}

	return EXIT_SUCCESS;
}

int deleteFile(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char msg[] = "NO FILES FOUND\n";
        send(sock, msg, bytes_read, 0);
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			syslog (LOG_NOTICE, "The file was already deleted.");
			return EXIT_FAILURE;;
		}

		alreadyRead -= (fileRecord.size + fileRecord.fileSize);
		fileRecord.isDeleted = 1;
		char record[sizeof(fileRecord)];
		memcpy(record, &fileRecord, sizeof(fileRecord));
		memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);

		char msg[] = "The file was successfuly deleted\n";
        send(sock, msg, bytes_read, 0);
		return EXIT_SUCCESS;
	}
	else
	{
		char msg[] = "The file not found on DISK\n";
        send(sock, msg, bytes_read, 0);
	}
}

readFileFromDisk(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		syslog (LOG_NOTICE, "NO FILES FOUND.");
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	alreadyRead -= fileRecord.fileSize;

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			syslog (LOG_NOTICE, "The file was deleted");
			return EXIT_FAILURE;
		}

		char msg[] = "File found\n";
        send(sock, msg, bytes_read, 0);

        char filePathRead[256];
        sprintf(filePathRead, "%s/%s", diskDirectory, (char *)fileName);

		buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
		fileptr = fopen(filePathRead, "wb");
		// fileptr = fopen("2.txt", "wb");
		memcpy(buffer, (diskBuffer + alreadyRead), fileRecord.fileSize);
		fwrite(buffer, fileRecord.fileSize, 1, fileptr);
		fclose(fileptr);
		char msg1[] = "File restored\n";
		send(sock, msg1, bytes_read, 0);
	}
	else
    {
        char msg[] = "File not found on disk\n";
        send(sock, msg, bytes_read, 0);
	}
}

int writeFileToDisk(char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size > 0)
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	strcpy(fileRecord.name, fileName);
    fileRecord.size = sizeof(fileRecord);

    char filePathWrite[256];
	sprintf(filePathWrite, "%s/%s", diskDirectory, (char *)fileName);

	fileRecord.fileSize = getFileLength(filePathWrite);
	fileRecord.isDeleted = 0;

	long checkDiskSpace = fileDisk.size - alreadyRead;
	if (checkDiskSpace < (fileRecord.fileSize + fileRecord.size))
	{
		char msg[] = "Not enougth space on disk\n";
        send(sock, msg, bytes_read, 0);
		return EXIT_FAILURE;;
	}

	char record[sizeof(fileRecord)];
	memcpy(record, &fileRecord, sizeof(fileRecord));
	memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);
	alreadyRead += fileRecord.size;

	fileptr = fopen(filePathWrite, "rb");
	if (fileptr == NULL)
	{
		syslog (LOG_NOTICE, "Can't open file for reading.");
		return EXIT_FAILURE;;
	}
	buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
	fread(buffer, fileRecord.fileSize, 1, fileptr);
	memcpy((diskBuffer + alreadyRead), buffer, fileRecord.fileSize);
	fclose(fileptr);
	char msg[] = "File successfully recorded\n";
    send(sock, msg, bytes_read, 0);
}

diskController(char *argv[])
{
    char discPath[256];
	sprintf(discPath, "%s/%s", diskDirectory, (char *)argv[2]);

	fileMapping(0, discPath, "");
	createMapViewOfFile(discPath, "");

	if (!file_exist(discPath))
	{
		char notFound[] = "Disk file to process not found\n";
		send(sock, notFound, bytes_read, 0);
	}

	if (!strcmp(argv[1], "write"))
	{
		writeFileToDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "read"))
	{
		readFileFromDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "erease"))
	{
		deleteFile(argv[3]);
	}
	else if (!strcmp(argv[1], "dir"))
	{
		printDiskFiles();
	}
	else if (!strcmp(argv[1], "squeeze"))
	{
		squeezeDisk(discPath);
	}
	else
	{
        char notRecognized[] = "Command do not recognized\n";
        send(sock, notRecognized, bytes_read, 0);
	}
}

int proceedCommands(char* argv[])
{
    char discPath[256];
	sprintf(discPath, "%s/%s", diskDirectory, (char *)argv[3]);

	if (!strcmp(argv[1], "format"))
	{
		fileMapping(argv[2], discPath, "format");
		createMapViewOfFile(discPath, "format");
	}
	else
	{
	    char discPathSecond[256];
	    sprintf(discPathSecond, "%s/%s", diskDirectory, (char *)argv[2]);

		if (!file_exist(discPathSecond))
		{
			char notFound[] = "Disk file not found\n";
			send(sock, notFound, bytes_read, 0);
            printExitMsg();
			return EXIT_FAILURE;
		}

		diskController(argv);
	}

    printExitMsg();
    close(hMapFile);

	return EXIT_SUCCESS;
}

int main()
{
    skeleton_daemon();
    syslog (LOG_NOTICE, "Disk daemon started.");
    mkdir(diskDirectory, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

    listener = socket(AF_INET, SOCK_STREAM, 0);
    if(listener < 0)
    {
        perror("socket");
        exit(1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(3425);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if(bind(listener, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("bind");
        exit(2);
    }

    listen(listener, 1);
    syslog (LOG_NOTICE, "Waiting to connect...");

    while(1)
    {
        sock = accept(listener, NULL, NULL);
        if(sock < 0)
        {
            syslog (LOG_NOTICE, "accept error exit...");
            exit(3);
        }

        syslog (LOG_NOTICE, "Сonnection established.");

        while(1)
        {
            bytes_read = recv(sock, buf, 1024, 0);
            if(bytes_read <= 0) break;

            char* argv[20];
            char* token;

            if (strcmp("exit",buf)==0)
            {
               syslog (LOG_NOTICE, "Exit.");
               return EXIT_FAILURE;;
            }

            else if (strcmp("",buf)!=0)
            {
               syslog (LOG_NOTICE, "Received.");
               syslog (LOG_NOTICE, "Sending back...");
            }

            token = strtok(buf, " ");

            int i=0;
            while( token != NULL )
            {
                argv[i] = token;
                i++;
                token = strtok(NULL, " ");
            }
            argv[i] = NULL;

            if (argv[0] != NULL && argv[1] != NULL && argv[2] != NULL)
            {
                proceedCommands(argv);
            }
            else
            {
                char notRecognized[] = "Command do not recognized\n";
                send(sock, notRecognized, bytes_read, 0);
                printExitMsg();
            }
        }

        syslog (LOG_NOTICE, "Disk daemon terminated.");
        closelog();
        close(sock);
    }

    return EXIT_SUCCESS;
}
