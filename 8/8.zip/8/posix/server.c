#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#include <stdlib.h>
#include <sys/types.h>
#include <sys/mman.h>

const minDiskSize = 1;
const maxDiskSize = 100000000;

void *diskBuffer;
int hMapFile;
int result;

FILE *fileptr, *fileptr2;
char *buffer, *buffer2;
size_t filelen;

struct disk
{
	int size;
	int type;
} fileDisk;

struct file
{
	long size;
	long fileSize;
	char name[256];
	int isDeleted;
} fileRecord;

int file_exist(char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

long getFileLength(char *filename)
{
	FILE *exein;
	unsigned long fileLen;
	exein = fopen(filename, "rb");

	if (exein == NULL)
	{
		perror("file open for reading");
		exit(EXIT_FAILURE);
	}

	fseek(exein, 0L, SEEK_END);
	fileLen = ftell(exein);
	fseek(exein, 0L, SEEK_SET);
	fclose(exein);

	return fileLen;
}

int fileMapping(char *fileSize, char *fileName, char *format[], int *server_to_client)
{
	long diskSize;

	if (file_exist(fileName))
	{
		diskSize = getFileLength(fileName);
	}
	else
	{
		diskSize = strtol(fileSize, NULL, 10);
	}

	if (diskSize < minDiskSize || diskSize > maxDiskSize)
	{
        char pipeMsg[] = "Incorrect disk size (min size - 1 and max size - 8192000)\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));

		return 1;
	}

    if (!strcmp(format, "format"))
    {
        hMapFile = open(fileName, O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
    }
    else
    {
        hMapFile = open(fileName, O_RDWR);
    }

    if (hMapFile == -1) {
        perror("Error opening file for writing");
        exit(EXIT_FAILURE);
    }

	if (!strcmp(format, "format"))
    {
        result = lseek(hMapFile, diskSize-1, SEEK_SET);
        if (result == -1)
        {
            close(hMapFile);
            perror("Error calling lseek() to 'stretch' the file");
            exit(EXIT_FAILURE);
        }

        result = write(hMapFile, "", 1);
        if (result != 1)
        {
            close(hMapFile);
            perror("Error writing last byte of the file");
            exit(EXIT_FAILURE);
        }
    }
}

createMapViewOfFile(char *fileName, char *format[], int *server_to_client)
{
	long diskSize = getFileLength(fileName);
    diskBuffer = mmap((caddr_t)0, diskSize, PROT_READ | PROT_WRITE, MAP_SHARED, hMapFile, 0);

    if (diskBuffer == MAP_FAILED)
    {
        close(hMapFile);
        perror("Error mmapping the file");

        char pipeMsg[] = "Error mmapping the file\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));

        exit(EXIT_FAILURE);
    }

	if (!strcmp(format, "format"))
	{
		fileDisk.size = diskSize;
		fileDisk.type = 1;

		char diskInfo[sizeof(fileDisk)];
		memcpy(diskInfo, &fileDisk, sizeof(fileDisk));
		memcpy(diskBuffer, &diskInfo, sizeof(fileDisk));

        char pipeMsg[] = "The disk was successfully created\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
	}
}

readDiskInfo(int *server_to_client)
{
	memcpy(&fileDisk, diskBuffer, sizeof(fileDisk));

    char pipeMsg[] = "\nDISK size -                            .\n";
    snprintf(pipeMsg + 14, 16, "%d", fileDisk.size);
    write(server_to_client,pipeMsg,strlen(pipeMsg));

    char pipeMsg1[] = "\n";
    write(server_to_client,pipeMsg1,strlen(pipeMsg1));
}

int squeezeDisk(char *fileName, int *server_to_client)
{
	long diskSize = getFileLength(fileName);
	char* newDiskBuffer = (char *)malloc((diskSize + 1) * sizeof(char));

	readDiskInfo(server_to_client);
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char pipeMsg[] = "No files found. Nothing to squeeze\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
		return 1;
	}
	else
	{
		memcpy(newDiskBuffer, diskBuffer, sizeof(fileDisk));
		long alreadyWrite = sizeof(fileDisk);
		if (fileRecord.isDeleted == 0)
		{
			memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
			memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
			alreadyWrite += (fileRecord.size + fileRecord.fileSize);
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0 && fileRecord.isDeleted == 0)
			{
				memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
				memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
				alreadyWrite += (fileRecord.size + fileRecord.fileSize);
			}
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		memset(diskBuffer, 0, fileDisk.size);
		memcpy(diskBuffer, newDiskBuffer, alreadyWrite);
	}

	char pipeMsg[] = "queeze operation made successfuly\n";
	write(server_to_client,pipeMsg,strlen(pipeMsg));
	return 0;
}

int printDiskFiles(int *server_to_client)
{
	readDiskInfo(server_to_client);
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

    char pipeMsg[] = "\nStored on the disk:\n";
    write(server_to_client,pipeMsg,strlen(pipeMsg));

	if (fileRecord.size > 0)
	{
		int fileCount = 1;

        char pipeMsgFIle1[] = "\nFile name -                     \n";
        memcpy(pipeMsgFIle1 + 14, &fileRecord.name, 20);
        write(server_to_client,pipeMsgFIle1,strlen(pipeMsgFIle1));

        char pipeMsgFIle2[] = "\nFile size -         bytes \n";
        snprintf(pipeMsgFIle2 + 14, sizeof(long), "%d", fileRecord.fileSize);
        write(server_to_client,pipeMsgFIle2,strlen(pipeMsgFIle2));

        char pipeMsgFIle3[] = " bytes\nIs deleted -         \n";
        snprintf(pipeMsgFIle3 + 20, sizeof(long), "%d", fileRecord.isDeleted);
        write(server_to_client,pipeMsgFIle3,strlen(pipeMsgFIle3));

		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
				fileCount++;

				strcpy (pipeMsgFIle1,"\n\nFile name -                     \n");
                memcpy(pipeMsgFIle1 + 16, &fileRecord.name, 20);
                write(server_to_client,pipeMsgFIle1,strlen(pipeMsgFIle1));

                strcpy (pipeMsgFIle2,"\nFile size -         bytes \n");
                snprintf(pipeMsgFIle2 + 13, sizeof(long), "%d", fileRecord.fileSize);
                write(server_to_client,pipeMsgFIle2,strlen(pipeMsgFIle2));

                strcpy (pipeMsgFIle3," bytes\nIs deleted -         \n");
                snprintf(pipeMsgFIle3 + 20, sizeof(long), "%d", fileRecord.isDeleted);
                write(server_to_client,pipeMsgFIle3,strlen(pipeMsgFIle3));
			}
		}
	}
	else
	{
		char diskStored[] = "No records on Disk\n";
        write(server_to_client,diskStored,strlen(diskStored));
		return 1;
	}
	return 0;
}

int deleteFile(char *fileName, int *server_to_client)
{
	readDiskInfo(server_to_client);
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		char pipeMsg[] = "NO FILES FOUND\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			printf("The file was already deleted\n");
			return 1;
		}

		alreadyRead -= (fileRecord.size + fileRecord.fileSize);
		fileRecord.isDeleted = 1;
		char record[sizeof(fileRecord)];
		memcpy(record, &fileRecord, sizeof(fileRecord));
		memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);

		char pipeMsg[] = "The file was successfuly deleted\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
		return 0;
	}
	else
	{
		char pipeMsg[] = "The file not found on DISK\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
	}
}

readFileFromDisk(char *fileName, int *server_to_client)
{
	readDiskInfo(server_to_client);
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		printf("NO FILES FOUND");
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	alreadyRead -= fileRecord.fileSize;

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			printf("The file was deleted\n");
			return 1;
		}

		char pipeMsg[] = "file found\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));

		buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
		fileptr = fopen(fileName, "wb");
		// fileptr = fopen("2.txt", "wb");
		memcpy(buffer, (diskBuffer + alreadyRead), fileRecord.fileSize);
		fwrite(buffer, fileRecord.fileSize, 1, fileptr);
		fclose(fileptr);
		char pipeMsg1[] = "file restored\n";
        write(server_to_client,pipeMsg1,strlen(pipeMsg1));
	}
}

int writeFileToDisk(char *fileName, int *server_to_client)
{
	readDiskInfo(server_to_client);
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size > 0)
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	fileRecord.size = sizeof(fileRecord);
	fileRecord.fileSize = getFileLength(fileName);
	strcpy(fileRecord.name, fileName);
	fileRecord.isDeleted = 0;

	long checkDiskSpace = fileDisk.size - alreadyRead;
	if (checkDiskSpace < (fileRecord.fileSize + fileRecord.size))
	{
		char pipeMsg[] = "Not enougth space on disk\n";
        write(server_to_client,pipeMsg,strlen(pipeMsg));
		return 1;
	}

	char record[sizeof(fileRecord)];
	memcpy(record, &fileRecord, sizeof(fileRecord));
	memcpy(diskBuffer + alreadyRead, &record, fileRecord.size);
	alreadyRead += fileRecord.size;

	fileptr = fopen(fileName, "rb");
	if (fileptr == NULL)
	{
		printf("Can't open file for reading\n");
		return 1;
	}
	buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
	fread(buffer, fileRecord.fileSize, 1, fileptr);
	memcpy((diskBuffer + alreadyRead), buffer, fileRecord.fileSize);
	fclose(fileptr);
	char pipeMsg[] = "File successfully recorded\n";
    write(server_to_client,pipeMsg,strlen(pipeMsg));
}

diskController(char *argv[], int *server_to_client)
{
	fileMapping(0, argv[2], "", server_to_client);
	createMapViewOfFile(argv[2], "", server_to_client);

	if (!file_exist(argv[2]))
	{
		char notFound[] = "Disk file to process not found\n";
		write(server_to_client,notFound,strlen(notFound));
	}

	if (!strcmp(argv[1], "write"))
	{
		writeFileToDisk(argv[3], server_to_client);
	}
	else if (!strcmp(argv[1], "read"))
	{
		readFileFromDisk(argv[3], server_to_client);
	}
	else if (!strcmp(argv[1], "erease"))
	{
		deleteFile(argv[3], server_to_client);
	}
	else if (!strcmp(argv[1], "dir"))
	{
		printDiskFiles(server_to_client);
	}
	else if (!strcmp(argv[1], "squeeze"))
	{
		squeezeDisk(argv[2], server_to_client);
	}
	else
	{
        char notRecognized[] = "Command do not recognized\n";
        write(server_to_client,notRecognized,strlen(notRecognized));
	}
}

int proceedCommands(char* argv[], int *server_to_client)
{
	if (!strcmp(argv[1], "format"))
	{
		fileMapping(argv[2], argv[3], "format", server_to_client);
		createMapViewOfFile(argv[3], "format", server_to_client);
	}
	else
	{
		if (!file_exist(argv[2]))
		{
			char notFound[] = "Disk file not found\n";
            write(server_to_client,notFound,strlen(notFound));

			return 1;
		}

		diskController(argv, server_to_client);
	}

    if (!strcmp(argv[1], "format"))
    {
        long diskSize = getFileLength(argv[3]);
    }
    else
    {
        long diskSize = getFileLength(argv[2]);
    }

    close(hMapFile);

	return 0;
}

int main()
{
   int client_to_server;
   char *myfifo = "/tmp/client_to_server_fifo";

   int server_to_client;
   char *myfifo2 = "/tmp/server_to_client_fifo";

   char buf[BUFSIZ];

   char* argv[20];
   char* token;

   /* create the FIFO (named pipe) */
   mkfifo(myfifo, 0666);
   mkfifo(myfifo2, 0666);

   /* open, read, and display the message from the FIFO */
   client_to_server = open(myfifo, O_RDONLY);
   server_to_client = open(myfifo2, O_WRONLY);

   printf("Server ON.\n");

   while (1)
   {
      read(client_to_server, buf, BUFSIZ);

      if (strcmp("exit",buf)==0)
      {
         printf("Server OFF.\n");
         break;
      }

      else if (strcmp("",buf)!=0)
      {
         printf("Received: %s\n", buf);
         printf("Sending back...\n");
      }

      token = strtok(buf, " ");

        int i=0;
        //walk through other tokens
        while( token != NULL ) {
            argv[i] = token;
            i++;
            token = strtok(NULL, " ");
            }
        argv[i] = NULL; //argv ends with NULL

        if (argv[0] != NULL && argv[1] != NULL && argv[2] != NULL)
        {
            proceedCommands(argv, server_to_client);
        }

      /* clean buf from any data */
      memset(buf, 0, BUFSIZ);
   }

   close(client_to_server);
   close(server_to_client);

   unlink(myfifo);
   unlink(myfifo2);
   return 0;
}
