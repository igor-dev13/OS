#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

printCommands()
{
	printf("\nUse this commands:\n");
	printf("1. disk.exe format <disk size> <disk name> (min size - 1 and max size - 100000000)\n");
	printf("2. disk.exe dir <disk name>\n");
	printf("3. disk.exe write <disk name> <fileToWriteOnDisk>\n");
	printf("4. disk.exe read <disk name> <fileToReadFromDisk>\n");
	printf("5. disk.exe erease <disk name> <fileToEreaseFromDisk>\n");
	printf("6. disk.exe squeeze <disk name>\n\n");
}

int main()
{
   int client_to_server;
   char *myfifo = "/tmp/client_to_server_fifo";

   int server_to_client;
   char *myfifo2 = "/tmp/server_to_client_fifo";

   char str[BUFSIZ];
   printf("Input message to serwer: ");

   printCommands();


   while(1) {
       printf("> ");
       gets(str);
       /* write str to the FIFO */
       client_to_server = open(myfifo, O_WRONLY);
       server_to_client = open(myfifo2, O_RDONLY);

       write(client_to_server, str, sizeof(str));

       perror("Write:"); //Very crude error check

       int c = 1, d = 1;
       for ( c = 1 ; c <= 32767 ; c++ )
           for ( d = 1 ; d <= 64 ; d++ )
           {}

       perror("Read:"); // Very crude error check
       read(server_to_client,str,sizeof(str));
       printf("...received from the server: %s\n\n",str);
       memset(str, 0, BUFSIZ);
   }

   close(client_to_server);
   close(server_to_client);

   /* remove the FIFO */

   return 0;
}
