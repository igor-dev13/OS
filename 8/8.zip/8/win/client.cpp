// client.cpp : Defines the entry point for the console application.
//
#define _CRT_SECURE_NO_WARNINGS

#include <windows.h> 
#include <stdio.h>
#include <conio.h>
#include <tchar.h>

#define BUFSIZE 512

int _tmain(int argc, TCHAR *argv[])
{
	HANDLE hPipe;
	LPTSTR lpvMessage = TEXT("Default message from client.");
	TCHAR  chBuf[BUFSIZE];
	BOOL   fSuccess = FALSE;
	wchar_t str[50];
	DWORD  cbRead, cbToWrite, cbWritten, dwMode;
	LPTSTR lpszPipename = TEXT("\\\\.\\pipe\\mynamedpipe");
	TCHAR menuCommands[] = TEXT(""
		"\nUse this commands:\n"
		"1. disk.exe format <disk size> <disk name> (min size - 1 and max size - 100000000)\n"
		"2. disk.exe dir <disk name>\n"
		"3. disk.exe write <disk name> <fileToWriteOnDisk>\n"
		"4. disk.exe read <disk name> <fileToReadFromDisk>\n"
		"5. disk.exe erease <disk name> <fileToEreaseFromDisk>\n"
		"6. disk.exe squeeze <disk name>\n"
		"7. exit - to exit programm\n\n");	

	// Try to open a named pipe; wait for it, if necessary. 

	while (1)
	{
		hPipe = CreateFile(
			lpszPipename,   // pipe name 
			GENERIC_READ |  // read and write access 
			GENERIC_WRITE,
			0,              // no sharing 
			NULL,           // default security attributes
			OPEN_EXISTING,  // opens existing pipe 
			0,              // default attributes 
			NULL);          // no template file 

							// Break if the pipe handle is valid. 

		if (hPipe != INVALID_HANDLE_VALUE)
			break;

		// Exit if an error other than ERROR_PIPE_BUSY occurs. 

		if (GetLastError() != ERROR_PIPE_BUSY)
		{
			_tprintf(TEXT("Could not open pipe. GLE=%d\n"), GetLastError());
			return -1;
		}

		// All pipe instances are busy, so wait for 20 seconds. 

		if (!WaitNamedPipe(lpszPipename, 20000))
		{
			printf("Could not open pipe: 20 second wait timed out.");
			return -1;
		}
	}

	wchar_t * pwc;
	wchar_t * input[10];
	int i = 0;
	wprintf(L"%s", menuCommands);

	while (1)
	{		
		wprintf(L"%s", L"> ");
		_getws_s(str);
		lpvMessage = str;		

		// The pipe connected; change to message-read mode. 

		dwMode = PIPE_READMODE_MESSAGE;
		fSuccess = SetNamedPipeHandleState(
			hPipe,    // pipe handle 
			&dwMode,  // new pipe mode 
			NULL,     // don't set maximum bytes 
			NULL);    // don't set maximum time 
		if (!fSuccess)
		{
			_tprintf(TEXT("SetNamedPipeHandleState failed. GLE=%d\n"), GetLastError());
			return -1;
		}

		// Send a message to the pipe server. 

		cbToWrite = (lstrlen(lpvMessage) + 1) * sizeof(TCHAR);
		_tprintf(TEXT("Sending %d byte message: \"%s\"\n"), cbToWrite, lpvMessage);

		fSuccess = WriteFile(
			hPipe,                  // pipe handle 
			lpvMessage,             // message 
			cbToWrite,              // message length 
			&cbWritten,             // bytes written 
			NULL);                  // not overlapped 

		if (!fSuccess)
		{
			_tprintf(TEXT("WriteFile to pipe failed. GLE=%d\n"), GetLastError());
			return -1;
		}

		printf("\nMessage sent to server, receiving reply as follows:\n");
		
		pwc = wcstok(str, L" ");
		while (pwc != NULL)
		{
			input[i] = pwc;			
			pwc = wcstok(NULL, L" ");			
			i++;
		}
		i = 0;

		if ((wcscmp(input[0], L"exit")) == 0)
		{	
			CloseHandle(hPipe);
			return 0;
		}

		while (1)
		{
			fSuccess = ReadFile(
				hPipe,    // pipe handle 
				chBuf,    // buffer to receive reply 
				BUFSIZE * sizeof(TCHAR),  // size of buffer 
				&cbRead,  // number of bytes read 
				NULL);    // not overlapped 

			if ((!fSuccess && GetLastError() != ERROR_MORE_DATA) || ((wcscmp(chBuf, L"exit")) == 0))
				break;

			_tprintf(TEXT("\"%s\"\n"), chBuf);

			if (!fSuccess)
			{
				_tprintf(TEXT("ReadFile from pipe failed. GLE=%d\n"), GetLastError());
				return -1;
			}

			if ((wcscmp(input[1], L"dir")) == 0)
			{
				continue;
			}
			else
			{
				break;
			}
		}
	}

	printf("\n<End of message, press ENTER to terminate connection and exit>");
	_getch();

	CloseHandle(hPipe);

	return 0;
}
