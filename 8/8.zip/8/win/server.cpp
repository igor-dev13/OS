// server.cpp : Defines the entry point for the console application.
//
#define _CRT_SECURE_NO_WARNINGS

#include <windows.h> 
#include <stdio.h> 
#include <tchar.h>
#include <strsafe.h>
#include <string>

#define BUFSIZE 512

HANDLE hHeap = GetProcessHeap();
TCHAR* pchRequest = (TCHAR*)HeapAlloc(hHeap, 0, BUFSIZE * sizeof(TCHAR));
TCHAR* pchReply = (TCHAR*)HeapAlloc(hHeap, 0, BUFSIZE * sizeof(TCHAR));

DWORD cbBytesRead = 0, cbReplyBytes = 0, cbWritten = 0;
BOOL fSuccess = FALSE;
HANDLE hPipe = NULL;

DWORD WINAPI InstanceThread(LPVOID);
int GetAnswerToRequest(LPTSTR, LPTSTR, LPDWORD, DWORD);

TCHAR szName[] = TEXT("Global\\MyFileMappingObject");
const int minDiskSize = 1;
const int maxDiskSize = 100000000;

LPCTSTR diskBuffer;
HANDLE hFile;
HANDLE hMapFile;

FILE *fileptr, *fileptr2;
char *buffer, *buffer2;
size_t filelen;

struct disk
{
	int size;
	int type;
} fileDisk;

struct file
{
	long size;
	long fileSize;
	char name[256];
	int isDeleted;
} fileRecord;

int writeToPipe(TCHAR pipeAnswer[])
{
	StringCchCopy(pchReply, BUFSIZE, pipeAnswer);
	cbReplyBytes = (lstrlen(pchReply) + 1) * sizeof(TCHAR);
	fSuccess = WriteFile(hPipe, pchReply, cbReplyBytes, &cbWritten, NULL);

	if (!fSuccess || cbReplyBytes != cbWritten)
	{
		_tprintf(TEXT("InstanceThread WriteFile failed, GLE=%d.\n"), GetLastError());
		printf("err");
	}
	return 0;
}

int file_exist(const char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

long getFileLength(const char *filename)
{
	FILE *exein;
	unsigned long fileLen;
	exein = fopen(filename, "rb");

	if (exein == NULL)
	{
		perror("file open for reading");
		exit(EXIT_FAILURE);
	}

	fseek(exein, 0L, SEEK_END);
	fileLen = ftell(exein);
	fseek(exein, 0L, SEEK_SET);
	fclose(exein);

	return fileLen;
}

int fileMapping(const char *fileSize, const char *fileName)
{
	long diskSize;

	if (file_exist(fileName))
	{
		diskSize = getFileLength(fileName);
	}
	else
	{
		diskSize = strtol(fileSize, NULL, 10);
	}

	if (diskSize < minDiskSize || diskSize > maxDiskSize)
	{
		TCHAR pipeAnswer[] = TEXT("Incorrect disk size (min size - 1024000 and max size - 8192000)\n");
		writeToPipe(pipeAnswer);
		return 1;
	}

	hFile = CreateFileA(fileName, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, NULL, NULL);
	hMapFile = CreateFileMapping(
		hFile,
		NULL,                   // default security
		PAGE_READWRITE,         // read/write access
		0,                      // max. object size
		diskSize,               // buffer size
		szName);                // name of mapping object		

	if (hMapFile == NULL)
	{
		_tprintf(TEXT("Could not create file mapping object (%d).\n"),
			GetLastError());
		return 1;
	}
	return 0;
}

int createMapViewOfFile(const char *fileName, const char format[])
{
	long diskSize = getFileLength(fileName);

	diskBuffer = (LPTSTR)MapViewOfFile(hMapFile,   // handle to map object
		FILE_MAP_ALL_ACCESS, // read/write permission
		0,
		0,
		diskSize);

	if (diskBuffer == NULL)
	{
		TCHAR pipeAnswer[] = TEXT("Could not map view of file (%d).\n");
		writeToPipe(pipeAnswer);

		printf("Could not map view of file (%d).\n",
			GetLastError());
		return 1;
	}

	if (!strcmp(format, "format"))
	{
		fileDisk.size = diskSize;
		fileDisk.type = 1;

		char diskInfo[sizeof(fileDisk)];
		memcpy(diskInfo, &fileDisk, sizeof(fileDisk));
		memcpy((void*)diskBuffer, &diskInfo, sizeof(fileDisk));

		TCHAR pipeAnswer[] = TEXT("The disk was successfully created\n");
		writeToPipe(pipeAnswer);
	}

	return 0;
}

int readDiskInfo()
{
	memcpy(&fileDisk, diskBuffer, sizeof(fileDisk));

	TCHAR pipeAnswer[] = TEXT("\nDISK size -                         \n");
	swprintf(pipeAnswer + 14, 16, L"%d", fileDisk.size);
	// writeToPipe(pipeAnswer);
	return 0;
}

int squeezeDisk(const char *fileName)
{
	long diskSize = getFileLength(fileName);
	char* newDiskBuffer = (char *)malloc((diskSize + 1) * sizeof(char));

	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		TCHAR pipeAnswer[] = TEXT("No files found. Nothing to squeeze\n");
		writeToPipe(pipeAnswer);
		return 1;
	}
	else
	{
		memcpy(newDiskBuffer, diskBuffer, sizeof(fileDisk));
		long alreadyWrite = sizeof(fileDisk) * 2;
		if (fileRecord.isDeleted == 0)
		{
			memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
			memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
			alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0 && fileRecord.isDeleted == 0)
			{
				memcpy((newDiskBuffer + alreadyWrite), (diskBuffer + alreadyRead), fileRecord.size);
				memcpy((newDiskBuffer + alreadyWrite + (fileRecord.size * 2)), (diskBuffer + alreadyRead + fileRecord.size), fileRecord.fileSize);
				alreadyWrite += (fileRecord.size + fileRecord.fileSize) * 2;
			}
			alreadyRead += (fileRecord.size + fileRecord.fileSize);
		}

		memset((void*)diskBuffer, 0, fileDisk.size);
		memcpy((void*)diskBuffer, newDiskBuffer, alreadyWrite);
	}

	TCHAR pipeAnswer[] = TEXT("Squeeze operation made successfuly\n");
	writeToPipe(pipeAnswer);
	return 0;
}

int printDiskFiles()
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));
	TCHAR pipeAnswer[] = TEXT("Stored on the disk:\n\n");
	writeToPipe(pipeAnswer);

	if (fileRecord.size > 0)
	{
		int fileCount = 1;

		wchar_t pipeMsgFIle1[] = TEXT("\nFile name -                     \n");
		swprintf((pipeMsgFIle1 + 14), (sizeof(fileRecord.name) * sizeof(TCHAR)), L"%hs", fileRecord.name);
		writeToPipe(pipeMsgFIle1);

		wchar_t pipeMsgFIle2[] = TEXT("\nFile size -         bytes \n");
		swprintf((pipeMsgFIle2 + 14), sizeof(long), L"%d", fileRecord.fileSize);
		writeToPipe(pipeMsgFIle2);

		wchar_t pipeMsgFIle3[] = TEXT(" bytes\nIs deleted -         \n");
		swprintf((pipeMsgFIle3 + 20), sizeof(long), L"%d", fileRecord.isDeleted);
		writeToPipe(pipeMsgFIle3);

		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
				fileCount++;
				
				wcscpy(pipeMsgFIle1, TEXT("\nFile name -                     \n"));
				swprintf((pipeMsgFIle1 + 14), (sizeof(fileRecord.name) * sizeof(TCHAR)), L"%hs", fileRecord.name);
				writeToPipe(pipeMsgFIle1);
				
				wcscpy(pipeMsgFIle2, TEXT("\nFile size -         bytes \n"));
				swprintf((pipeMsgFIle2 + 14), sizeof(long), L"%d", fileRecord.fileSize);
				writeToPipe(pipeMsgFIle2);

				wcscpy(pipeMsgFIle3, TEXT(" bytes\nIs deleted -         \n"));
				swprintf((pipeMsgFIle3 + 20), sizeof(long), L"%d", fileRecord.isDeleted);
				writeToPipe(pipeMsgFIle3);
				
			}
		}
	}
	else
	{
		TCHAR pipeAnswer[] = TEXT("No records on Disk\n");
		writeToPipe(pipeAnswer);
		return 1;
	}

	TCHAR pipeAnswerExit[] = TEXT("exit");
	writeToPipe(pipeAnswerExit);

	return 0;
}

int deleteFile(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		TCHAR pipeAnswer[] = TEXT("NO FILES FOUND\n");
		writeToPipe(pipeAnswer);
		return 1;
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			TCHAR pipeAnswer[] = TEXT("The file was already deleted\n");
			writeToPipe(pipeAnswer);
			return 1;
		}

		alreadyRead -= (fileRecord.size + fileRecord.fileSize);
		fileRecord.isDeleted = 1;
		char record[sizeof(fileRecord)];
		memcpy(record, &fileRecord, sizeof(fileRecord));
		memcpy((void*)(diskBuffer + alreadyRead), &record, fileRecord.size);

		TCHAR pipeAnswer[] = TEXT("The file was successfuly deleted\n");
		writeToPipe(pipeAnswer);
		return 0;
	}
	else
	{
		TCHAR pipeAnswer[] = TEXT("The file not found on DISK\n");
		writeToPipe(pipeAnswer);
	}
	return 0;
}

int readFileFromDisk(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size == 0)
	{
		TCHAR pipeAnswer[] = TEXT("NO FILES FOUND\n");
		writeToPipe(pipeAnswer);
		return 1;
	}
	else if (!strcmp(fileRecord.name, fileName))
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
	}
	else
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (strcmp(fileRecord.name, fileName) && alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	alreadyRead -= fileRecord.fileSize;

	if (!strcmp(fileRecord.name, fileName))
	{
		if (fileRecord.isDeleted == 1)
		{
			TCHAR pipeAnswer[] = TEXT("The file was deleted\n");
			writeToPipe(pipeAnswer);
			return 1;
		}
		buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
		fileptr = fopen(fileName, "wb");
		// fileptr = fopen("2.txt", "wb");
		memcpy(buffer, (diskBuffer + alreadyRead), fileRecord.fileSize);
		fwrite(buffer, fileRecord.fileSize, 1, fileptr);
		fclose(fileptr);
		free(buffer);
		TCHAR pipeAnswer[] = TEXT("File restored\n");
		writeToPipe(pipeAnswer);
	}
	else
	{
		TCHAR pipeAnswer[] = TEXT("This file not found\n");
		writeToPipe(pipeAnswer);
	}
	return 0;
}

int writeFileToDisk(const char *fileName)
{
	readDiskInfo();
	long alreadyRead = sizeof(fileDisk);
	memcpy(&fileRecord, diskBuffer + sizeof(fileDisk), sizeof(fileRecord));

	if (fileRecord.size > 0)
	{
		alreadyRead += (fileRecord.size + fileRecord.fileSize);
		while (alreadyRead < fileDisk.size && fileRecord.size > 0)
		{
			memcpy(&fileRecord, diskBuffer + alreadyRead, sizeof(fileRecord));
			if (fileRecord.size > 0)
			{
				alreadyRead += (fileRecord.size + fileRecord.fileSize);
			}
		}
	}

	fileRecord.size = sizeof(fileRecord);
	fileRecord.fileSize = getFileLength(fileName);
	strcpy(fileRecord.name, fileName);
	fileRecord.isDeleted = 0;

	long checkDiskSpace = fileDisk.size - alreadyRead;
	if (checkDiskSpace < (fileRecord.fileSize + fileRecord.size))
	{
		TCHAR pipeAnswer[] = TEXT("Not enougth space on disk\n");
		writeToPipe(pipeAnswer);
		return 1;
	}

	char record[sizeof(fileRecord)];
	memcpy(record, &fileRecord, sizeof(fileRecord));
	memcpy((void*)(diskBuffer + alreadyRead), &record, fileRecord.size);
	alreadyRead += fileRecord.size;

	fileptr = fopen(fileName, "rb");
	if (fileptr == NULL)
	{
		TCHAR pipeAnswer[] = TEXT("Can't open file for reading\n");
		writeToPipe(pipeAnswer);
		return 1;
	}
	buffer = (char *)malloc((fileRecord.fileSize + 1) * sizeof(char));
	fread(buffer, fileRecord.fileSize, 1, fileptr);
	memcpy((void*)(diskBuffer + alreadyRead), buffer, fileRecord.fileSize);
	fclose(fileptr);
	TCHAR pipeAnswer[] = TEXT("File successfully recorded\n");
	writeToPipe(pipeAnswer);
	return 0;
}

int diskController(const char *argv[])
{
	fileMapping(0, argv[2]);
	createMapViewOfFile(argv[2], "");

	if (!file_exist(argv[2]))
	{
		TCHAR pipeAnswer[] = TEXT("Disk file to process not found\n");		
		writeToPipe(pipeAnswer);
		return 1;
	}

	if (!strcmp(argv[1], "write"))
	{
		writeFileToDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "read"))
	{
		readFileFromDisk(argv[3]);
	}
	else if (!strcmp(argv[1], "dir"))
	{
		printDiskFiles();
	}
	else if (!strcmp(argv[1], "erease"))
	{
		deleteFile(argv[3]);
	}
	else if (!strcmp(argv[1], "squeeze"))
	{
		squeezeDisk(argv[2]);
	}
	else
	{
		TCHAR pipeAnswer[] = TEXT("Command do not recognized\n");
		writeToPipe(pipeAnswer);
		return 1;
	}
	return 0;
}

int _tmain(VOID)
{
	BOOL   fConnected = FALSE;
	DWORD  dwThreadId = 0;
	HANDLE hPipe = INVALID_HANDLE_VALUE, hThread = NULL;
	LPTSTR lpszPipename = TEXT("\\\\.\\pipe\\mynamedpipe");

	// The main loop creates an instance of the named pipe and 
	// then waits for a client to connect to it. When the client 
	// connects, a thread is created to handle communications 
	// with that client, and this loop is free to wait for the
	// next client connect request. It is an infinite loop.	

	for (;;)
	{
		_tprintf(TEXT("\nPipe Server: Main thread awaiting client connection on %s\n"), lpszPipename);
		hPipe = CreateNamedPipe(
			lpszPipename,             // pipe name 
			PIPE_ACCESS_DUPLEX,       // read/write access 
			PIPE_TYPE_MESSAGE |       // message type pipe 
			PIPE_READMODE_MESSAGE |   // message-read mode 
			PIPE_WAIT,                // blocking mode 
			PIPE_UNLIMITED_INSTANCES, // max. instances  
			BUFSIZE,                  // output buffer size 
			BUFSIZE,                  // input buffer size 
			0,                        // client time-out 
			NULL);                    // default security attribute 

		if (hPipe == INVALID_HANDLE_VALUE)
		{
			_tprintf(TEXT("CreateNamedPipe failed, GLE=%d.\n"), GetLastError());
			return -1;
		}

		// Wait for the client to connect; if it succeeds, 
		// the function returns a nonzero value. If the function
		// returns zero, GetLastError returns ERROR_PIPE_CONNECTED. 

		fConnected = ConnectNamedPipe(hPipe, NULL) ?
			TRUE : (GetLastError() == ERROR_PIPE_CONNECTED);

		if (fConnected)
		{
			printf("Client connected, creating a processing thread.\n");

			// Create a thread for this client. 
			hThread = CreateThread(
				NULL,              // no security attribute 
				0,                 // default stack size 
				InstanceThread,    // thread proc
				(LPVOID)hPipe,    // thread parameter 
				0,                 // not suspended 
				&dwThreadId);      // returns thread ID 

			if (hThread == NULL)
			{
				_tprintf(TEXT("CreateThread failed, GLE=%d.\n"), GetLastError());
				return -1;
			}
			else CloseHandle(hThread);
		}
		else
			// The client could not connect, so close the pipe. 
			CloseHandle(hPipe);
	}

	return 0;
}

DWORD WINAPI InstanceThread(LPVOID lpvParam)
// This routine is a thread processing function to read from and reply to a client
// via the open pipe connection passed from the main loop. Note this allows
// the main loop to continue executing, potentially creating more threads of
// of this procedure to run concurrently, depending on the number of incoming
// client connections.
{
	// Do some extra error checking since the app will keep running even if this
	// thread fails.

	if (lpvParam == NULL)
	{
		printf("\nERROR - Pipe Server Failure:\n");
		printf("   InstanceThread got an unexpected NULL value in lpvParam.\n");
		printf("   InstanceThread exitting.\n");
		if (pchReply != NULL) HeapFree(hHeap, 0, pchReply);
		if (pchRequest != NULL) HeapFree(hHeap, 0, pchRequest);
		return (DWORD)-1;
	}

	if (pchRequest == NULL)
	{
		printf("\nERROR - Pipe Server Failure:\n");
		printf("   InstanceThread got an unexpected NULL heap allocation.\n");
		printf("   InstanceThread exitting.\n");
		if (pchReply != NULL) HeapFree(hHeap, 0, pchReply);
		return (DWORD)-1;
	}

	if (pchReply == NULL)
	{
		printf("\nERROR - Pipe Server Failure:\n");
		printf("   InstanceThread got an unexpected NULL heap allocation.\n");
		printf("   InstanceThread exitting.\n");
		if (pchRequest != NULL) HeapFree(hHeap, 0, pchRequest);
		return (DWORD)-1;
	}

	// Print verbose messages. In production code, this should be for debugging only.
	printf("InstanceThread created, receiving and processing messages.\n");

	// The thread's parameter is a handle to a pipe object instance. 

	hPipe = (HANDLE)lpvParam;

	// Loop until done reading
	while (1)
	{
		// Read client requests from the pipe. This simplistic code only allows messages
		// up to BUFSIZE characters in length.
		fSuccess = ReadFile(
			hPipe,        // handle to pipe 
			pchRequest,    // buffer to receive data 
			BUFSIZE * sizeof(TCHAR), // size of buffer 
			&cbBytesRead, // number of bytes read 
			NULL);        // not overlapped I/O 

		if (!fSuccess || cbBytesRead == 0)
		{
			if (GetLastError() == ERROR_BROKEN_PIPE)
			{
				_tprintf(TEXT("InstanceThread: client disconnected.\n"), GetLastError());
			}
			else
			{
				_tprintf(TEXT("InstanceThread ReadFile failed, GLE=%d.\n"), GetLastError());
			}
			break;
		}
		
		// Process the incoming message.
		if (GetAnswerToRequest(pchRequest, pchReply, &cbReplyBytes, cbBytesRead) == 1)
			break;
	}

	// Flush the pipe to allow the client to read the pipe's contents 
	// before disconnecting. Then disconnect the pipe, and close the 
	// handle to this pipe instance. 

	FlushFileBuffers(hPipe);
	DisconnectNamedPipe(hPipe);
	CloseHandle(hPipe);

	HeapFree(hHeap, 0, pchRequest);
	HeapFree(hHeap, 0, pchReply);

	printf("InstanceThread exitting.\n");
	return 1;
}

int GetAnswerToRequest(LPTSTR pchRequest,
	LPTSTR pchReply2,
	LPDWORD pchBytes2,
	DWORD cbBytesRead2)
	// This routine is a simple function to print the client request to the console
	// and populate the reply buffer with a default data string. This is where you
	// would put the actual client request processing code that runs in the context
	// of an instance thread. Keep in mind the main thread will continue to wait for
	// and receive other client connections while the instance thread is working.
{
	_tprintf(TEXT("Client Request String:\"%s\"\n"), pchRequest);

	const char *processCommand[10];
	char * processRequest;
	TCHAR tempTchar[BUFSIZE];
	wcscpy(tempTchar, pchRequest);
	char tempString[BUFSIZE];
	sprintf(tempString, "%S", tempTchar);

	processRequest = strtok(tempString, " ");
	int i = 0;
	while (processRequest != NULL)
	{
		processCommand[i] = processRequest;
		i++;
		processRequest = strtok(NULL, " ");
	}

	if (!strcmp(processCommand[0], "exit"))
	{
		return 1;
	}

	if (!strcmp(processCommand[1], "format"))
	{
		fileMapping(processCommand[2], processCommand[3]);
		createMapViewOfFile(processCommand[3], "format");
	}
	else
	{
		if (!file_exist(processCommand[2]))
		{
			TCHAR pipeAnswer[] = TEXT("Disk file not found\n");
			TCHAR pipeAnswer2[] = TEXT("exit");
			writeToPipe(pipeAnswer);
			writeToPipe(pipeAnswer2);

			if (!fSuccess || cbReplyBytes != cbWritten)
			{
				_tprintf(TEXT("InstanceThread WriteFile failed, GLE=%d.\n"), GetLastError());
				printf("err");
			}
			return 1;
		}

		diskController(processCommand);
		return 0;
	}

	UnmapViewOfFile(diskBuffer);
	CloseHandle(hMapFile);
}
