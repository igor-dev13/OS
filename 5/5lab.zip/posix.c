#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int fdlock;

int get_lock(void)
{
	struct flock fl;

	fl.l_type = F_WRLCK;
	fl.l_whence = SEEK_SET;
	fl.l_start = 0;
	fl.l_len = 1;

	if ((fdlock = open("oneproc.lock", O_WRONLY | O_CREAT, 0666)) == -1)
		return 0;

	if (fcntl(fdlock, F_SETLK, &fl) == -1)
		return 0;

	return 1;
}

int main(void)
{
	if (!get_lock())
	{
		fputs("Process already running!\n", stderr);
		return 1;
	}

	getchar();
	return 0;
}